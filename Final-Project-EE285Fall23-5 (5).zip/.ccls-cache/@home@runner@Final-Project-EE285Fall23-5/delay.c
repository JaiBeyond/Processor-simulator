#include <stdio.h>
#include <time.h>

void delay(unsigned int secs) {
    unsigned int end = time(0) + secs;
    while (time(0) < end);
}

int main(void) {
  delay(21);
  return 0;
}