#include "simplelogic.h"
#include <stdio.h>

int main(void) {
  bit A = 1;
  bit B = 0;
  bit Cin = 1;

  printf("%d\n", fa_sum(A, B, Cin));
  printf("%d\n", fa_carry(A, B, Cin));
  printf("%d\n", and2(A, B));
  printf("%d\n", or2(A, B));
  printf("%d\n", xor2(A, B));
  printf("%d\n", inv(A));

  int test_input_base10 = 47;
  bit test_base2[32];
  int test_output_base10;
  Int2Bit(test_input_base10, test_base2);
  test_output_base10 = Bit2Int(test_base2);
  printf("Input value of %d is converted to ", test_input_base10);
  printf_bit16(test_base2);
  printf("\nWhen converted back to integer is %d\n", test_output_base10);

  return 0;
}