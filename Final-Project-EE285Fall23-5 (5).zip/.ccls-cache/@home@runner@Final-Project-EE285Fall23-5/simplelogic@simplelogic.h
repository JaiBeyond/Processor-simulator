#include <stdio.h>

typedef enum { BIT_LOW = 0, BIT_HIGH = 1, BIT_X = 2 } bit;

bit and2(bit A, bit B) {
  if (A == 0 & B == 0) {
    return 0;
  }
  if (A == 1 & B == 0) {
    return 0;
  }
  if (A == 0 & B == 1) {
    return 0;
  }
  if (A == 1 & B == 1) {
    return 1;
  }
}
bit xor2(bit A, bit B) {
  if (A == 0 & B == 0) {
    return 0;
  }
  if (A == 1 & B == 0) {
    return 1;
  }
  if (A == 0 & B == 1) {
    return 1;
  }
  if (A == 1 & B == 1) {
    return 0;
  }
}
bit or2(bit A, bit B) {
  if (A == 0 & B == 0) {
    return 0;
  }
  if (A == 0 & B == 1) {
    return 1;
  }
  if (A == 1 & B == 0) {
    return 1;
  }
  if (A == 1 & B == 1) {
    return 1;
  }
}
bit inv(bit A) {
  if (A == 0) {
    A = 1;
  } else {
    A = 0;
  }
}
int test_base2[16];
void Int2Bit(int dec_input, bit bin_output[]) {
  int i = 0;
  while (dec_input > 0) {
    i++;
    bin_output[i] = dec_input % 2;
    dec_input /= 2;
  }
}
int Bit2Int(bit bin_input[]) {
  int doubler = 1;
  int output_value = 0;

  for (int i = 1; i < 17; i++) {
    output_value = output_value + (bin_input[i] * doubler);
    doubler *= 2;
  }
  return output_value;
}
void printf_bit16(bit bin_input[]) {
  int i = 16;
  int flip = 1;
  while (i > 0) {
    if (bin_input[i] == 1) {
      flip = 1;
    }
    if (flip == 1) {
      printf("%d", bin_input[i]);
    }
    i--;
  }
}

bit fa_sum(bit A, bit B, bit Cin) { return xor2(xor2(A, B), Cin); }
bit fa_carry(bit A, bit B, bit Cin) {
  return or2(and2(xor2(A, B), Cin), and2(A, B));
}