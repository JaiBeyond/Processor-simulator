#include "simplelogic/simplelogic.h"
#include <ncurses.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void charconvert(bit A[], char *character) {
  char stringarray[26][1] = {"a", "b", "c", "d", "e", "f", "g", "h", "i",
                          "j", "k", "l", "m", "n", "o", "p", "q", "r",
                          "s", "t", "u", "v", "w", "x", "y", "z"};
  int lookup = Bit2Int(A);
  strcat(character,stringarray[lookup]);
}

void BITINT2BIT(long long data, bit A[17]) {

  int lastDigit;
  for (int i = 1; i < 17; i++) {
    /* Get the last digit */
    lastDigit = data % 10;
    data = data / 10;
    A[i] = lastDigit;
  }
}

bit DUPEBIT(bit A[], bit B[]) {
  for (int i = 1; i < 16; i++) {
    A[i] = B[i];
  }
}

bit invert(bit B[]) {
  for (int i = 1; i < 17; i++) {
    if (B[i] == 0) {
      B[i] = 1;
    } else {
      B[i] = 0;
    }
  }
}

// ALU START

void adder16(bit A[], bit B[], bit S[]) {
  /* 1+1 = 10
     1+0 = 1
     0+1 = 1
     0+0 = 0
  */

  bit C[17] = {};
  for (int i = 1; i < 17; i++) {
    S[i] = fa_sum(A[i], B[i], C[i]);
    C[i + 1] = fa_carry(A[i], B[i], C[i]);
  }

  for (int i = 1; i < 17; i++) {
  }
}
void sub16(bit A[], bit B[], bit S[]) {
  bit inverted[17] = {0};
  bit one[17] = {0};
  bit invertC[17] = {0};
  Int2Bit(1, one);
  invert(B);
  adder16(B, one, invertC);

  /*0 – 0 = 0
    0 – 1 = 1 ( with a borrow of 1)
    1 – 0 = 1
    1 – 1 = 0*/
  bit C[17] = {};
  for (int i = 1; i < 17; i++) {
    S[i] = fa_sum(A[i], invertC[i], C[i]);
    C[i + 1] = fa_carry(A[i], invertC[i], C[i]);
  }
}

void div16(bit A[], bit B[], bit Quotient[], bit R[]) {
  bit inverted[17] = {0};
  bit one[17] = {0};
  bit invertB[17] = {0};
  bit zero[17] = {0};
  bit S[17] = {};
  Quotient[17] = 0;
  bit QH[17] = {0};
  bit BN[17] = {0};
  bit PA[17] = {0};

  DUPEBIT(BN, B);

  Int2Bit(1, one);
  invert(B);
  adder16(B, one, invertB);
  while (Bit2Int(A) != 0) {
    if (Bit2Int(A) == 32767) {
      sub16(Quotient, one, QH);
      DUPEBIT(Quotient, QH);
      break;
    }
    DUPEBIT(R, A);
    adder16(Quotient, one, QH);
    DUPEBIT(Quotient, QH);

    adder16(A, invertB, S);
    DUPEBIT(A, S);
  }

  if (Bit2Int(A) == 0) {
    DUPEBIT(R, zero);
  }
}

void multi16(bit A[], bit B[], bit P[]) {
  // rules of multiplication in binary
  // 0 * 0 = 0
  // 0 * 1 = 0
  // 1 * 0 = 0
  // 1 * 1 = 1
  bit hold[17] = {0};
  bit C[17] = {};
  bit S[17] = {};
  bit zero[17] = {0};
  for (int i = 1; i < 16; i++) {
    for (int j = 1; j < 16; j++) {
      if (B[i] == 1) {
        hold[j + i - 1] = A[j];
      } else {
        hold[j + i - 1] = 0;
      }
      hold[j + i] = 0;
    }
    DUPEBIT(C, zero);
    for (int i = 1; i < 16; i++) {
      S[i] = fa_sum(hold[i], P[i], C[i]);
      C[i + 1] = fa_carry(hold[i], P[i], C[i]);
    }
    for (int i = 1; i < 16; i++) {
      P[i] = S[i];
      hold[i] = 0;
    }
  }
}

void ALU(bit A[], bit B[], bit S[], int O, bit R[]) {

  if (O == 0) {
    adder16(A, B, S);
  }
  if (O == 1) {
    sub16(A, B, S);
  }
  if (O == 2) {
    multi16(A, B, S);
  }
  if (O == 3) {
    div16(A, B, S, R);
  }
}

int counter_int(int counter) {
  counter++;
  // 65535
  if (counter > 2047) {
    counter = 0;
  }
  return counter;
}

void counter_up(bit counter[17]) {
  bit one[17] = {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  bit data[33];
  adder16(counter, one, data);
  DUPEBIT(counter, data);
}

// ALU END

// GLOBAL VARIABLES

int input;
bit input_data[17];
int count_int;
bool clock_start = true;
bit counter[17] = {0};
bit A[17] = {};
bit B[17] = {};
bit S[17] = {};
int A1;
int B1;
int O1;
int carry_bit;
long long num;
int MEMORY_SIZE = 2047;
#define MEMORY_SIZE 2047

long long MEMORY_DATA[MEMORY_SIZE] = {};

int INSTRUCTION_SIZE = 2047;
#define INSTRUCTION_SIZE 2047

long long INSTRUCTION_DATA[INSTRUCTION_SIZE] = {};

char *character;
char Buffer[MEMORY_SIZE];
char Buffer2[INSTRUCTION_SIZE];

bit holder[17];
bit REG_A[17] = {0000000000000000};
bit REG_B[17] = {0000000000000000};
bit REG_C[17] = {0000000000000000};

bit MEMORY_DATA_BIT[17] = {0};

bit BUS[17] = {0000000000000000};
bit INSTUCTION_REG[17] = {0000000000000000};
bit INSTRUCTION_DATA_Current[17] = {0000000000000000};

bit instruction_data_first[17] = {0};
bit instruction_data_last[17] = {0};

// Instruction set

// NOP        00000 : no operation
// AIN <addr> 00001 : load data from <addr> to reg A
// BIN <addr> 00010 : load data from <addr> to reg B
// CIN <addr> 00011 : load data from <addr> to reg C
// LDIA <val> 00100 : immediately load <val> in reg A
// LDIB <val> 00101 : immediately load <val> in reg B
// RDEXP      00110 : load value stored on the expansion port
// WEXP       00111 : copy reg A into expansion port to reg A
// STA <addr> 01000 : store value of A into <addr> of memory
// STC <addr> 01001 : store value of C into <addr> of memory
// ADD        01010 : add reg A and reg B, and set reg A to sum
// SUB        01011 : subtract reg B from reg A, and set a to sum
// MULT       01100 : multiply reg B with reg A, and set A to the answer
// DIV        01101 : divide reg A by reg B and set A to the answer
// JMP <val>  01110 : change counter to <val>
// JMPZ <val> 01111 : jump to <val> if the value in reg A. is equal to 0
// JMPC <val> 10000 : jump if the carry bit is set
// LDAIN      10001 : load reg A as memory address, then copy val
// STAOUT     10010 : load reg A as memory address, then copy val
// LDLGE      10011 : use value after instruction as address to
// STLGE      10100 : use value after couter as address to copy
// SWP        10101 : swap register A and register B
// SWPC       10110 : swap register A and register C
// HLT        10111 : stop the clock
// ABUS       11000 : reads reg A to Bus.
// PCA        11001 : prints single character stored in reg A

// Micro instructions

// RA : read from reg A to bus
void RA() { DUPEBIT(BUS, REG_A); }
// RB : read from reg B to bus
void RB() { DUPEBIT(BUS, REG_B); }
// RC : read from reg C to bus
void RC() { DUPEBIT(BUS, REG_C); }
// RM : read from memory to bus at the address in mem addr. register
void RM(bit Address[]) {
  bit DATA[17];
  int num;
  Int2Bit(MEMORY_DATA[Bit2Int(Address)], DATA);
  DUPEBIT(BUS, DATA);
}
// IR : read from lowest 12 bits of instruction register to bus
void IR() {
  bit L12[17] = {0};

  DUPEBIT(BUS, L12);
}
// CR : read value from counter to bus
void CR() { DUPEBIT(BUS, counter); }
// RE : read from expansion port to bus
void RE(bit A[], bit B[], bit P[]) {}
// WA : write from bus to reg A
void WA() { DUPEBIT(REG_A, BUS); }
// WB : write from bus to reg B
void WB() { DUPEBIT(REG_B, BUS); }
// WC : write from bus to reg C
void WC() { DUPEBIT(REG_C, BUS); }
// IW : write from bus to instruction register
void IW(bit A[], bit B[], bit P[]) {}
// DW : write from bus to display register
void DW(bit A[], bit B[], bit P[]) {}

int main(void) {
  system("clear");
  // Largest number able to fit on the address bus is 2047 (as an int) this
  // would be 11 1's The remaining 5 bits are for instuction flags only this
  // will provide 31 possible instructions

  while (clock_start) {
    // counter_up(counter);

    count_int = counter_int(count_int);
    for (int i = 1; i < 17; i++) {
      counter[i] = 0;
    }
    Int2Bit(count_int, counter);

    BITINT2BIT(INSTRUCTION_DATA[count_int], INSTUCTION_REG);

    // file create MEMORY
    FILE *MEMORY;
    char buff[255];

    MEMORY = fopen("MEMORY.txt", "r");
    if (MEMORY == NULL) {
      MEMORY = fopen("MEMORY.txt", "w+");
      for (int i = 1; i < MEMORY_SIZE + 1; i++) {
        fputs("00000000000", MEMORY);
        if (i < MEMORY_SIZE) {
          fputs("\n", MEMORY);
        }
      }

      fclose(MEMORY);
    }
    // read file into array
    for (int i = 1; i < MEMORY_SIZE; i++) {
      fgets(Buffer, MEMORY_SIZE, MEMORY);
      num = atoll(Buffer);
      MEMORY_DATA[i] = num;
    }
    fclose(MEMORY);

    // file create INSTRUCTION SET
    FILE *INSTRUCTION;
    char buff2[255];

    INSTRUCTION = fopen("INSTRUCTION.txt", "r");
    if (INSTRUCTION == NULL) {
      INSTRUCTION = fopen("INSTRUCTION.txt", "w+");
      for (int i = 1; i < INSTRUCTION_SIZE + 1; i++) {
        fputs("0000000000000000", INSTRUCTION);
        if (i < INSTRUCTION_SIZE) {
          fputs("\n", INSTRUCTION);
        }
      }

      fclose(INSTRUCTION);
    }
    // read file into array
    for (int i = 1; i < INSTRUCTION_SIZE; i++) {
      fgets(Buffer2, INSTRUCTION_SIZE, INSTRUCTION);
      num = atoll(Buffer2);
      INSTRUCTION_DATA[i] = num;
    }
    fclose(INSTRUCTION);

    // splitting the instruction data
    for (int i = 11; i-- > 1;) {
      instruction_data_last[i] = INSTUCTION_REG[i];
    }
    for (int i = 17; i-- > 12;) {
      instruction_data_first[i - 11] = INSTUCTION_REG[i];
    }

    if (Bit2Int(instruction_data_first) == 1) {
      // AIN
      BITINT2BIT(MEMORY_DATA[Bit2Int(instruction_data_last)], MEMORY_DATA_BIT);
      // gets data from the memory address (part of bus_data_last) and sets
      // REG_A to the data found at that address.
      DUPEBIT(REG_A, MEMORY_DATA_BIT);
    }
    if (Bit2Int(instruction_data_first) == 2) {
      // BIN

      // gets data from the memory address (part of bus_data_last) and sets
      // REG_B to the data found at that address.
      DUPEBIT(REG_B, instruction_data_last);
    }
    if (Bit2Int(instruction_data_first) == 3) {
      // CIN

      // gets data from the memory address (part of bus_data_last) and sets
      // REG_C to the data found at that address.
      DUPEBIT(REG_C, instruction_data_last);
    }
    if (Bit2Int(instruction_data_first) == 4) {
      // LDIA

      // immediately load <val> in reg A

      DUPEBIT(REG_A, instruction_data_last);
    }
    if (Bit2Int(instruction_data_first) == 5) {
      // LDIB

      // immediately load <val> in reg B

      DUPEBIT(REG_B, instruction_data_last);
      printf("\n");
    }
    if (Bit2Int(instruction_data_first) == 6) {
      // RDEXP

      scanf("%d", &input);
      Int2Bit(input, input_data);
      DUPEBIT(REG_A, input_data);
      // load value stored on the expansion port
    }
    if (Bit2Int(instruction_data_first) == 7) {
      // WEXP
      printf("%d", Bit2Int(REG_A));
      // copy reg A into expansion port
    }
    if (Bit2Int(instruction_data_first) == 8) {
      // STA
      MEMORY_DATA[Bit2Int(instruction_data_last)] = Bit2Int(REG_A);
      // store value of A into <addr> of memory
    }
    if (Bit2Int(instruction_data_first) == 9) {
      // STC
      MEMORY_DATA[Bit2Int(instruction_data_last)] = Bit2Int(REG_C);
      // store value of C into <addr> of memory
    }
    if (Bit2Int(instruction_data_first) == 10) {
      // ADD
      bit sum[17] = {0};
      adder16(REG_A, REG_B, sum);
      DUPEBIT(REG_A, sum);
      // add reg A to reg B and store in reg A
    }
    if (Bit2Int(instruction_data_first) == 11) {
      // SUB
      bit sum[17] = {0};
      sub16(REG_A, REG_B, sum);
      DUPEBIT(REG_A, sum);
      // subtract reg B from reg A and store in reg A
    }
    if (Bit2Int(instruction_data_first) == 12) {
      // MULT
      bit RESULT[17] = {0};
      multi16(REG_A, REG_B, RESULT);
      DUPEBIT(REG_A, RESULT);
      // multiply reg A by reg B and store in reg A
    }
    if (Bit2Int(instruction_data_first) == 13) {

      // DIV
      bit RESULT[17] = {0};
      bit R[17] = {0};
      div16(REG_A, REG_B, RESULT, R); // remainder needs complete

      // divide reg A by reg B and store in reg A
    }
    if (Bit2Int(instruction_data_first) == 14) {
      // JMP <val>
      count_int = Bit2Int(instruction_data_last);
      // change counter to <val>
    }
    if (Bit2Int(instruction_data_first) == 15) {
      // JMPZ <val>
      if (Bit2Int(REG_A) == 0) {
        count_int = Bit2Int(instruction_data_last);
      }
      // jump to <val> if the value in reg A. is equal to 0
    }
    if (Bit2Int(instruction_data_first) == 16) {
      // JMPC <val>
      if (carry_bit) {
        count_int = Bit2Int(instruction_data_last);
      }

      // jump if the carry bit is set
    }
    if (Bit2Int(instruction_data_first) == 17) {
      // LDAIN
      BITINT2BIT(MEMORY_DATA[Bit2Int(REG_A)], REG_A);

      // load reg A as memory address, then copy val
    }
    if (Bit2Int(instruction_data_first) == 18) {
      // STAOUT
      // load reg A as memory address, then copy val from reg A to memory
      // address
    }
    if (Bit2Int(instruction_data_first) == 19) {
      // LDLGE

      // use value after instruction as address to
    }
    if (Bit2Int(instruction_data_first) == 20) {
      // STLGE

      // use value after counter as address to copy
    }
    if (Bit2Int(instruction_data_first) == 21) {
      // SWP
      DUPEBIT(holder, REG_A);
      DUPEBIT(REG_A, REG_B);
      DUPEBIT(REG_B, holder);
      // swap register A and register B
    }
    if (Bit2Int(instruction_data_first) == 22) {
      // SWPC
      DUPEBIT(holder, REG_A);
      DUPEBIT(REG_A, REG_C);
      DUPEBIT(REG_C, holder);
      // swap register A and register C
    }
    if (Bit2Int(instruction_data_first) == 23) {
      // HLT
      clock_start = false;
      // stop the clock
    }
    if (Bit2Int(instruction_data_first) == 24) {
      // ABUS
      RA();
      // reads reg A to Bus.
    }
    if (Bit2Int(instruction_data_first) == 25) {
      // PCA

      // will convert data in reg A to (character) to be printed

      charconvert(REG_A, character);

      // prints the converted data (character)
      char *newline = "`";
      if (strcmp(newline, character) == 0) {
        printf("\n");
      } else {
        printf("%s", character);
      }
      // prints single character stored in reg A
    }

    // console Visuals
    /*printf("Counter:%d  ", count_int);

    printf("      ");
    printf_bit16(BUS);

    printf("      ");
    BITINT2BIT(INSTRUCTION_DATA[count_int],INSTRUCTION_DATA_Current);
    printf_bit16(INSTUCTION_REG);

    printf("      ");
    printf_bit16(instruction_data_first);

    printf("\n");*/
  }
  return 0;
}