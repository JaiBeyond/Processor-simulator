gcc -L./ -Wl,-rpath=./ -o main main.c -lsimplelogic

bash "runner.sh"