#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int INSTRUCTION_SIZE_int = 2047;
#define INSTRUCTION_SIZE 2047
long long num;
char Buffer[INSTRUCTION_SIZE];
char Buffer2[INSTRUCTION_SIZE];

long long INSTRUCTION_DATA[INSTRUCTION_SIZE] = {};
char INSTRUCTION_DATA_char[] = {};
char *data;

// global variables
const char *A = "AIN", *B = "BIN", *C = "CIN", *D = "LDIA", *E = "LDIB",
           *F = "RDEXP", *G = "WEXP", *H = "STA", *I = "STC", *J = "ADD",
           *K = "SUB", *L = "MULT", *M = "DIV", *N = "JMP", *O = "JMPZ",
           *P = "JMPC", *Q = "LDAIN", *R = "STAOUT", *S = "LDLGE", *T = "STLGE",
           *U = "SWP", *V = "SWPC", *W = "HLT", *X = "LDIA", *Y = "LDIA",
           *Z = "END";
;
char a[INSTRUCTION_SIZE] = "00001", b[INSTRUCTION_SIZE] = "00010",
     c[INSTRUCTION_SIZE] = "00011", d[INSTRUCTION_SIZE] = "00100",
     e[INSTRUCTION_SIZE] = "00101", f[INSTRUCTION_SIZE] = "00110",
     g[INSTRUCTION_SIZE] = "00111", h[INSTRUCTION_SIZE] = "01000",
     i2[INSTRUCTION_SIZE] = "01001", j[INSTRUCTION_SIZE] = "01010",
     k[INSTRUCTION_SIZE] = "01011", l[INSTRUCTION_SIZE] = "01100",
     m[INSTRUCTION_SIZE] = "01101", n[INSTRUCTION_SIZE] = "01110",
     o[INSTRUCTION_SIZE] = "01111", p[INSTRUCTION_SIZE] = "10000",
     q[INSTRUCTION_SIZE] = "10001", r[INSTRUCTION_SIZE] = "10010",
     s[INSTRUCTION_SIZE] = "10011", t[INSTRUCTION_SIZE] = "10100",
     u[INSTRUCTION_SIZE] = "10101", v[INSTRUCTION_SIZE] = "10110",
     w[INSTRUCTION_SIZE] = "10111", x[INSTRUCTION_SIZE] = "11000",
     y[INSTRUCTION_SIZE] = "11001";

int main(void) {
  FILE *INSTRUCTION2;
  char buff[255];

  FILE *INSTRUCTION;
  char buff2[255];
  char DATA_Array[INSTRUCTION_SIZE] = {};

  // file create INSTRUCTION UNCOMPILED

  INSTRUCTION = fopen("INSTRUCTION UNCOMPILED.txt", "r");
  if (INSTRUCTION == NULL) {
    INSTRUCTION = fopen("INSTRUCTION UNCOMPILED.txt", "w+");
    for (int i = 1; i < INSTRUCTION_SIZE + 1; i++) {
      fputs("", INSTRUCTION);
      if (i < INSTRUCTION_SIZE) {
        fputs("\n", INSTRUCTION);
      }
    }

    fclose(INSTRUCTION);
  }
INSTRUCTION2 = fopen("INSTRUCTION COMPILED.txt", "w+");
  // read file into array
  for (int i = 1; i < INSTRUCTION_SIZE; i++) {

    fgets(Buffer2, INSTRUCTION_SIZE, INSTRUCTION);

    // convert Buffers to binary

    strncpy(Buffer, Buffer2, INSTRUCTION_SIZE);
    for (int i = 0, j; Buffer[i] != '\0'; ++i) {

      while (!(Buffer[i] >= '0' && Buffer[i] <= '9') &&
             !(Buffer[i] >= '0' && Buffer[i] <= '9') && !(Buffer[i] == '\0')) {
        for (j = i; Buffer[j] != '\0'; ++j) {

          // if jth element of line is not an alphabet,
          // assign the value of (j+1)th element to the jth element
          Buffer[j] = Buffer[j + 1];
        }
        Buffer[j] = '\0';
      }

      // enter the loop if the character is not an alphabet
      // and not the null character
      while (!(Buffer2[i] >= 'a' && Buffer2[i] <= 'z') &&
             !(Buffer2[i] >= 'A' && Buffer2[i] <= 'Z') &&
             !(Buffer2[i] == '\0')) {
        for (j = i; Buffer2[j] != '\0'; ++j) {

          // if jth element of line is not an alphabet,
          // assign the value of (j+1)th element to the jth element
          Buffer2[j] = Buffer2[j + 1];
        }
        Buffer2[j] = '\0';
      }
    }
    

    if (strcmp(Buffer2, A) == 0) {
      data = strcat(a, Buffer);
    }
    if (strcmp(Buffer2, B) == 0) {
      data = strcat(b, Buffer);
    }
    if (strcmp(Buffer2, C) == 0) {
      data = strcat(c, Buffer);
    }
    if (strcmp(Buffer2, D) == 0) {
      data = strcat(d, Buffer);
    }
    if (strcmp(Buffer2, E) == 0) {
      data = strcat(e, Buffer);
    }
    if (strcmp(Buffer2, F) == 0) {
      data = strcat(f, Buffer);
    }
    if (strcmp(Buffer2, G) == 0) {
      data = strcat(g, Buffer);
    }
    if (strcmp(Buffer2, H) == 0) {
      data = strcat(h, Buffer);
    }
    if (strcmp(Buffer2, I) == 0) {
      data = strcat(i2, Buffer);
    }
    if (strcmp(Buffer2, J) == 0) {
      data = strcat(j, Buffer);
    }
    if (strcmp(Buffer2, K) == 0) {
      data = strcat(k, Buffer);
    }
    if (strcmp(Buffer2, L) == 0) {
      data = strcat(l, Buffer);
    }
    if (strcmp(Buffer2, M) == 0) {
      data = strcat(m, Buffer);
    }
    if (strcmp(Buffer2, N) == 0) {
      data = strcat(n, Buffer);
    }
    if (strcmp(Buffer2, O) == 0) {
      data = strcat(o, Buffer);
    }
    if (strcmp(Buffer2, P) == 0) {
      data = strcat(p, Buffer);
    }
    if (strcmp(Buffer2, Q) == 0) {
      data = strcat(q, Buffer);
    }
    if (strcmp(Buffer2, R) == 0) {
      data = strcat(r, Buffer);
    }
    if (strcmp(Buffer2, S) == 0) {
      data = strcat(s, Buffer);
    }
    if (strcmp(Buffer2, T) == 0) {
      data = strcat(t, Buffer);
    }
    if (strcmp(Buffer2, U) == 0) {
      data = strcat(u, Buffer);
    }
    if (strcmp(Buffer2, V) == 0) {
      data = strcat(v, Buffer);
    }
    if (strcmp(Buffer2, W) == 0) {
      data = strcat(w, Buffer);
    }
    if (strcmp(Buffer2, Z) == 0) {
      data = "0000000000000000";
      printf("test\n");
    }

    printf("Line: %d   Output String: %s  Output Num: %s       Combined "
           "binary:%s\n",
           i, Buffer2, Buffer, data);

    // file create INSTRUCTION COMPILED



    fputs(data, INSTRUCTION2);
    fputs("\n", INSTRUCTION2);


  }
  fclose(INSTRUCTION);

  // Instruction set

  // NOP        00000 : no operation
  // AIN <addr> 00001 : load data from <addr> to reg A
  // BIN <addr> 00010 : load data from <addr> to reg B
  // CIN <addr> 00011 : load data from <addr> to reg C
  // LDIA <val> 00100 : immediately load <val> in reg A
  // LDIB <val> 00101 : immediately load <val> in reg B
  // RDEXP      00110 : load value stored on the expansion port
  // WEXP       00111 : copy reg A into expansion port
  // STA <addr> 01000 : store value of A into <addr> of memory
  // STC <addr> 01001 : store value of C into <addr> of memory
  // ADD        01010 : add reg A and reg B, and set reg A to sum
  // SUB        01011 : subtract reg B from reg A, and set a to sum
  // MULT       01100 : multiply reg B with reg A, and set A to the answer
  // DIV        01101 : divide reg A by reg B and set A to the answer
  // JMP <val>  01110 : change counter to <val>
  // JMPZ <val> 01111 : jump to <val> if the value in reg A. is equal to 0
  // JMPC <val> 10000 : jump if the carry bit is set
  // LDAIN      10001 : load reg A as memory address, then copy val
  // STAOUT     10010 : load reg A as memory address, then copy val
  // LDLGE      10011 : use value after instruction as address to
  // STLGE      10100 : use value after couter as address to copy
  // SWP        10101 : swap register A and register B
  // SWPC       10110 : swap register A and register C
  // HLT        10111 : stop the clock

  return 0;
}